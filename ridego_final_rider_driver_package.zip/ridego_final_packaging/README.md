# RideGo Final Packaging — Rider + Driver

This package separates the mobile applications into:
- `rider/` — RideGo Rider
- `driver/` — RideGo Driver

Both are Flutter projects and are ready for the Android build stage.

## Build Rider APK
cd rider
flutter pub get
flutter build apk --release

## Build Driver APK
cd driver
flutter pub get
flutter build apk --release

Expected release APKs:
- rider/build/app/outputs/flutter-apk/app-release.apk
- driver/build/app/outputs/flutter-apk/app-release.apk

## Important
The UI projects are packaged separately, but the production backend still needs
to be connected and configured with real credentials/providers before release.
The current screens include functional UI/state demonstrations, not a claim of
a production-ready ride network.

Configure:
- API_BASE_URL
- Google Maps Android API key
- OTP provider
- push notifications
- payment gateway
- authenticated realtime backend
